// Copyright 2018 The Flutter team. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.
import 'package:english_words/english_words.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:hello_me/providers/settings_notifier.dart';
import 'package:provider/provider.dart';
import 'dart:async';
import 'dart:developer' as developer;



void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(App());
}


class App extends StatelessWidget {
  final Future<FirebaseApp> _initialization = Firebase.initializeApp();
  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: _initialization,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Scaffold(
              body: Center(
                  child: Text(snapshot.error.toString(),
                      textDirection: TextDirection.ltr)));
        }
        if (snapshot.connectionState == ConnectionState.done) {
          return const MyApp();
        }
        return const Center(child: CircularProgressIndicator());
      },
    );
  }
}

// #docregion MyApp
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // #docregion build
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => AuthNotifier(),
      child: MaterialApp(
        title: 'Startup Name Generator',
        theme: ThemeData(
          appBarTheme: const AppBarTheme(
            backgroundColor: Colors.deepPurple,
            foregroundColor: Colors.white,
          ),
        ),
        home: const RandomWords(),
      ),
    );
  }
// #enddocregion build
}
// #enddocregion MyApp


class RandomWords extends StatefulWidget {
  const RandomWords({Key? key}) : super(key: key);

  @override
  State<RandomWords> createState() => _RandomWordsState();
}
// #docregion RWS-var
class _RandomWordsState extends State<RandomWords> {
  final _suggestions = <WordPair>[];
  final _localsaved = <WordPair>{};
  final _remoteSaved = <String>{};
  final _biggerFont = const TextStyle(fontSize: 18);
  final _firestore = FirebaseFirestore.instance;

  Future<bool> _addUser(String email) async {
    try {
      await _firestore.collection('users').doc(email).set({
        'suggestions': [],
      });
      return true;
    } catch (e) {
      developer.log(e.toString(), name: 'Signup error');
      return false;
    }
  }


  Future<bool> _addSuggestion (Set<String> suggestions) async {
    try {
      await _firestore.collection('users').doc(context.read<AuthNotifier>().email).update({
        'suggestions': FieldValue.arrayUnion([...suggestions])});
      return true;
    } catch (e) {
      developer.log(e.toString(), name: 'adding val');
      return false;
    }
  }


  Future<bool> _remSuggestion (String suggestion) async {
    try {
      DocumentSnapshot<Map<String, dynamic>> remoteData = await _firestore.collection('users').doc(context.read<AuthNotifier>().email).get();
      List userSaved = remoteData?.get('suggestions');
      userSaved.removeWhere((str){
        return str == suggestion;
      });
      if (!mounted) return false;
      _firestore.collection('users')
            .doc(context.read<AuthNotifier>().email)
            .update({'suggestions': userSaved});
      // remote_suggestions.remove(suggestion);
      // List new_remote_set = remote_suggestions.toList();
      // if(!mounted) return false;
      // await _firestore.collection('users').doc(context.read<AuthNotifier>().email).update({
      // 'suggestions': new_remote_set});
      return true;
    } catch (e) {
      developer.log(e.toString(), name: 'removing val');
      return false;
    }
  }

  Future _sync () async{
    try {
      //first create a set of strings, so that we can use it to synce to the server
      //adding them to the currently empty remote set
      Set<String> localSuggestions = _localsaved.map((element){
        _remoteSaved.add(element.asPascalCase);
        return element.asPascalCase;
      }).toSet();
      var remoteData = await _firestore.collection('users').doc(context.read<AuthNotifier>().email).get();
      var remoteSuggestions = remoteData?.data()?["suggestions"].toSet();
      developer.log("we got the data", name: "data fine");
      developer.log("${remoteSuggestions.toString()}", name: "remote data ");
      //add the remote elements as well
      remoteSuggestions.forEach((element) {
        _remoteSaved.add(element);
        // var words = element.toString().split("(?=\\p{Upper})");
        final beforeCapitalLetter = RegExp(r"(?=[A-Z])");
        var parts = element.toString().split(beforeCapitalLetter);
        if (parts.isNotEmpty && parts[0].isEmpty) parts = parts.sublist(1);
        developer.log("words: ${parts.toString()} , element in remote saved: ${element.toString()} , element split: ${(element.toString().split("(?=\\p{Upper})")).toString()}", name: "words split");
        var pair = WordPair(parts[0], parts[1]);
        if (_suggestions.contains(pair)){
          _localsaved.add(pair);
        }
        developer.log(_remoteSaved.toString(), name: 'Synced');
      });
      _addSuggestion(localSuggestions);
    } catch (e) {
      developer.log(e.toString(), name: 'Sync error');
      return;
    }
  }



  void _pushSaved() {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (context) {
          developer.log(_remoteSaved.toString(), name: 'remote');
          developer.log(_localsaved.toString(), name: 'local');
          Set<dynamic> saved = context.read<AuthNotifier>().status == Status.Authenticated?
          _remoteSaved
              : _localsaved.map((e) => e.asPascalCase).toSet();
          developer.log(saved.toString(), name: 'saved');
          final tiles = saved.map((pair) {
              return Dismissible(
                background: Container(
                  color: Colors.deepPurple,
                  child: Row(
                    children:  const [
                      Padding(
                        padding: EdgeInsets.all(8.0),
                        child: Icon(
                          Icons.delete,
                          color: Colors.white,
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.all(8.0),
                        child: Text(
                          'Delete Suggestion',
                          style :TextStyle(
                            fontSize: 14,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                key: UniqueKey(),
                child: ListTile(
                  title: Text(pair.toString()),
                ),
                confirmDismiss: (DismissDirection direction) {
                  return showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        return AlertDialog(
                          title: const Text('Delete suggestion'),
                          content: Text('are you sure you want to delete: ${pair.toString()} ?'),
                          actions: <Widget>[
                            TextButton(
                              child: const Text('Yes'),
                              onPressed: () {
                                if(context.read<AuthNotifier>().status == Status.Authenticated){
                                  _remoteSaved.remove(pair.toString());
                                  _remSuggestion(pair.toString());
                                }
                                final beforeCapitalLetter = RegExp(r"(?=[A-Z])");
                                var parts = pair.toString().split(beforeCapitalLetter);
                                if (parts.isNotEmpty && parts[0].isEmpty) parts = parts.sublist(1);
                                var wordpair = WordPair(parts[0].toLowerCase(), parts[1].toLowerCase());
                                setState(() {
                                  _localsaved.remove(wordpair);
                                });
                                Navigator.of(context).pop(true);
                              },
                            ),TextButton(
                              child: const Text('No'),
                              onPressed: () {
                                Navigator.of(context).pop(false);
                              },
                            ),
                          ],
                        );
                      }
                  );
                },
              );
            },
          );
          final divided = tiles.isNotEmpty
              ? ListTile.divideTiles(
            context: context,
            tiles: tiles,
          ).toList()
              : <Widget>[];
          return Scaffold(
            appBar: AppBar(
              title: const Text('Saved Suggestions'),
            ),
            body: ListView(children: divided),
          );
        },
      ),
    );
  }
  void _login() {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (context) {
          TextEditingController _emailController = TextEditingController();
          TextEditingController _passwordController = TextEditingController();
          bool isLoading = context.watch<AuthNotifier>().status == Status.Authenticating;
          return Scaffold(
            appBar: AppBar(
              title: const Text('Login'),
              foregroundColor: Colors.white,
            ),
            body: Column
              (
                children: [
                const Padding(
                    padding: EdgeInsets.all(10.0)
                ),
                const Padding(
                  padding: EdgeInsets.all(10.0),
                  child: Text(
                    'Welcome to Startup Names Generator, please log in!',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(18.0),
                  child: TextField(
                    controller: _emailController,
                    decoration: const InputDecoration(
                      border: UnderlineInputBorder(),
                      hintText: 'Email',
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: TextField(
                    controller: _passwordController,
                    decoration: const InputDecoration(
                      border: UnderlineInputBorder(),
                      hintText: 'Password',
                    ),
                    obscureText: true,
                  ),
                ),
                const Padding(
                  padding: EdgeInsets.all(12),
                ),
                SizedBox(
                  width: 300.0,
                  height: 40.0,
                  child: TextButton(
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all<Color>(Colors.deepPurple),
                      foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                    ),
                    onPressed: isLoading ? null : () async{
                        bool signRes = await context.read<AuthNotifier>().signIn(_emailController.text, _passwordController.text);
                        if (signRes){
                          await _sync();
                          setState(() {
                            Navigator.of(context).pop(); // pop of login page
                          });
                          developer.log("sync succesful",name:"sync end",);
                        } else{
                          if (!mounted) return;
                          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                              content: Text('There was an error logging into the app')));
                        }
                    },
                    child: isLoading
                        ? const Center(child: CircularProgressIndicator())
                    : const Text('login'),
                  ),
                ),
                const Padding(
                  padding: EdgeInsets.all(12),
                ),
                SizedBox(
                  width: 300.0,
                  height: 40.0,
                  child: TextButton(
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all<Color>(Colors.deepPurple),
                      foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                    ),
                    onPressed: isLoading ? null : () async{
                      Future<UserCredential?> signUpRes = context.read<AuthNotifier>().signUp(_emailController.text, _passwordController.text);
                      UserCredential? signedUp = await signUpRes;
                      if (signedUp != null){
                        Future<bool> addResFut = _addUser(_emailController.text);
                        bool addRes = await addResFut;
                        if (addRes){
                          if (!mounted) return;
                          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                              content: Text('You have signed up, you may now sign in')));
                        }else {
                          if (!mounted) return;
                          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                              content: Text('There was an error Signing up the app')));
                        }
                      } else{
                        if (!mounted) return;
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                            content: Text('There was an error Signing up to the app')));
                      }
                    },
                    child: isLoading
                        ? const Center(child: CircularProgressIndicator())
                        : const Text('Signup'),
                  ),
                )
              ]
            ),
          );
        },
      ),
    );
  }
  void _logout() async {
    _remoteSaved.clear();
    await context.read<AuthNotifier>().signOut();
    if(!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Successfully logged out'),));
}
  // #enddocregion RWS-var

  // #docregion RWS-build
  @override
  Widget build(BuildContext context) {
    bool loggedIn = context.watch<AuthNotifier>().status == Status.Authenticated;
    // #docregion itemBuilder
    return Scaffold(
        appBar: AppBar(
          title: const Text('Startup Name Generator'),
          actions: <Widget>[
            IconButton(
            icon: const Icon(Icons.star),
            onPressed: _pushSaved,
            tooltip: 'Saved Suggestions',
            ),
            IconButton(
              icon: loggedIn ? const Icon(Icons.exit_to_app) : const Icon(Icons.login),
              onPressed: loggedIn ? _logout : _login,
              tooltip: 'Login',
            ),
          ],
        ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16.0),
        itemBuilder: /*1*/ (context, i) {
          if (i.isOdd) return const Divider(); /*2*/

          final index = i ~/ 2; /*3*/
          if (index >= _suggestions.length) {
            _suggestions.addAll(generateWordPairs().take(10)); /*4*/
          }
          final alreadySaved = _localsaved.contains(_suggestions[index]);
          // #docregion listTile
          return ListTile(
            title: Text(
              _suggestions[index].asPascalCase,
              style: _biggerFont,
            ),
            trailing: Icon(
              alreadySaved ? Icons.favorite : Icons.favorite_border,
              color: alreadySaved ? Colors.red : null,
              semanticLabel: alreadySaved ? 'Remove from saved' : 'Save',
            ),
            onTap: () {          // NEW from here ...
              setState(() {
                if (alreadySaved) {
                  if (context.read<AuthNotifier>().status == Status.Authenticated) {
                    developer.log("you were authorized", name: 'Auth');
                    _remoteSaved.remove(_suggestions[index].asPascalCase);
                    _remSuggestion(_suggestions[index].asPascalCase);
                  }
                  _localsaved.remove(_suggestions[index]);
                } else {
                  if (context.read<AuthNotifier>().status == Status.Authenticated) {
                    _remoteSaved.add(_suggestions[index].asPascalCase);
                    _addSuggestion({_suggestions[index].asPascalCase});
                  }
                  _localsaved.add(_suggestions[index]);
                }
              });                // to here.
            },
          );
          // #enddocregion listTile
        },
      ),
    );
    // #enddocregion itemBuilder
  }
// #enddocregion RWS-build
// #docregion RWS-var
}
// #enddocregion RWS-var
