import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'dart:developer' as developer;


enum Status{
  Authenticating,
  Unauthenticated,
  Authenticated
}

class AuthNotifier extends ChangeNotifier {
  final _auth = FirebaseAuth.instance;
  Status _status = Status.Unauthenticated;
  User? _user = null;
  String? _email;


  AuthNotifier(){
    _auth.authStateChanges().listen( (User? firebaseUser) async {
      if (firebaseUser == null) {
        _user = null;
        _status = Status.Unauthenticated;
      }
      else {
        _user = firebaseUser;
        _status = Status.Authenticated;
      }
      notifyListeners();
    } );
  }

  Status get status => _status;
  String? get email => _email;

  Future<UserCredential?> signUp(String email, String password) async {
    try {
      _status = Status.Authenticating;
      notifyListeners();
      return await _auth.createUserWithEmailAndPassword(
          email: email,
          password: password
      );
    }
    catch (e) {
      developer.log(e.toString(), name: 'Signup error');
      _status = Status.Unauthenticated;
      notifyListeners();
      return null;
    }
  }

  Future<bool> signIn(String email, String password) async {
    try {
      _status = Status.Authenticating;
      notifyListeners();
      await _auth.signInWithEmailAndPassword(
          email: email,
          password: password
      );
      _email = email;
      return true;
    }
    catch (e) {
      // developer.log(e.toString(), name: 'SignIn error');
      _status = Status.Unauthenticated;
      notifyListeners();
      return false;
    }
  }

  Future<bool> signOut() async {
    try {
      _status = Status.Unauthenticated;
      notifyListeners();
      await _auth.signOut();
      _email = null;
      return true;
    }
    catch (e) {
      // developer.log(e.toString(), name: 'SignIn error');
      _status = Status.Unauthenticated;
      notifyListeners();
      return false;
    }
  }

}

