package com.technion.android.hello_me

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
